import pandas as pd

fichier = r"C:\Users\p\Sunu_Rotation\data\processed\mboro_monthly.csv"

df = pd.read_csv(fichier)

print("\n===== COLONNES =====")
print(df.columns.tolist())

print("\n===== APERCU =====")
print(df.head(10).to_string(index=False))

print("\n===== STATISTIQUES =====")
print(df.describe().round(2).to_string())