
import json
import time
from pathlib import Path

import requests
import pandas as pd

# ==========================================
# 1. CONFIGURATION
# ==========================================

BASE_URL = (
    "https://power.larc.nasa.gov/api/temporal/daily/point"
)

START_DATE = "20010101"
END_DATE = "20251231"

PARAMETERS = [
    "T2M",
    "T2M_MAX",
    "T2M_MIN",
    "PRECTOTCORR",
    "RH2M",
    "ALLSKY_SFC_SW_DWN"
]

COMMUNITY = "AG"

# Coordonnées approximatives du site pilote
SITES = {
    "Mboro": {
        "latitude": 15.14051,
        "longitude": -16.88682
    }
}


ROOT = Path(__file__).resolve().parents[2]

RAW_DIR = ROOT / "data" / "raw" / "nasa_power"
PROCESSED_DIR = ROOT / "data" / "processed"
REPORT_DIR = ROOT / "reports"

for folder in [RAW_DIR, PROCESSED_DIR, REPORT_DIR]:
    folder.mkdir(parents=True, exist_ok=True)


# ==========================================
# 2. COLLECTE NASA POWER
# ==========================================

def collect_data(site_name, coordinates):

    latitude = coordinates["latitude"]
    longitude = coordinates["longitude"]

    params = {
        "parameters": ",".join(PARAMETERS),
        "community": COMMUNITY,
        "latitude": latitude,
        "longitude": longitude,
        "start": START_DATE,
        "end": END_DATE,
        "format": "JSON",
        "time-standard": "UTC"
    }

    print(f"\nCollecte NASA POWER : {site_name}")

    for attempt in range(3):

        try:
            response = requests.get(
                BASE_URL,
                params=params,
                timeout=180
            )

            response.raise_for_status()
            result = response.json()
            break

        except (requests.RequestException, ValueError) as error:

            print(f"Erreur tentative {attempt + 1}/3 : {error}")

            if attempt == 2:
                raise

            time.sleep(5 * (attempt + 1))

    # Sauvegarde de la réponse originale
    raw_file = RAW_DIR / f"{site_name.lower()}_raw.json"

    with open(raw_file, "w", encoding="utf-8") as file:
        json.dump(
            result,
            file,
            ensure_ascii=False,
            indent=2
        )

    # Extraction des séries journalières
    data = result["properties"]["parameter"]

    df = pd.DataFrame(data)

    df.index = pd.to_datetime(
        df.index,
        format="%Y%m%d"
    )

    df.index.name = "date"

    # Conversion numérique
    df = df.apply(pd.to_numeric, errors="coerce")

    # Valeurs manquantes NASA
    df = df.replace(-999, float("nan"))

    # Métadonnées
    df["site"] = site_name
    df["latitude"] = latitude
    df["longitude"] = longitude

    # Contrôle de la période
    df = df.sort_index()

    output_file = (
        PROCESSED_DIR / f"{site_name.lower()}_daily.csv"
    )

    df.to_csv(output_file, encoding="utf-8")

    # Sauvegarde des métadonnées
    metadata_file = (
        RAW_DIR / f"{site_name.lower()}_metadata.json"
    )

    metadata = {
        "site": site_name,
        "latitude": latitude,
        "longitude": longitude,
        "start_date": START_DATE,
        "end_date": END_DATE,
        "parameters": PARAMETERS,
        "community": COMMUNITY,
        "time_standard": "UTC",
        "source": "NASA POWER Daily API"
    }

    with open(metadata_file, "w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=4)

    print("\nCOLLECTE TERMINEE")
    print("Nombre de lignes :", len(df))
    print("Première date :", df.index.min())
    print("Dernière date :", df.index.max())
    print("Fichier :", output_file)

    return df


# ==========================================
# 3. CONTROLE DE QUALITE
# ==========================================

def quality_report(df, site_name):

    variables = [
        "T2M",
        "T2M_MAX",
        "T2M_MIN",
        "PRECTOTCORR",
        "RH2M",
        "ALLSKY_SFC_SW_DWN"
    ]

    report = pd.DataFrame({
        "variable": variables,
        "valeurs_valides": [
            df[col].notna().sum() for col in variables
        ],
        "valeurs_manquantes": [
            df[col].isna().sum() for col in variables
        ],
        "taux_manquant_pct": [
            df[col].isna().mean() * 100 for col in variables
        ]
    })

    report.to_csv(
        REPORT_DIR / f"{site_name.lower()}_quality.csv",
        index=False
    )

    print("\nRAPPORT DE QUALITE")
    print(report.to_string(index=False))

    # Vérification des dates en double
    print("\nDates dupliquées :", df.index.duplicated().sum())

    # Statistiques descriptives
    print("\nSTATISTIQUES DESCRIPTIVES")
    print(df[variables].describe())


# ==========================================
# 4. AGREGATION MENSUELLE
# ==========================================

def monthly_analysis(df, site_name):

    variables = [
        "T2M",
        "T2M_MAX",
        "T2M_MIN",
        "PRECTOTCORR",
        "RH2M",
        "ALLSKY_SFC_SW_DWN"
    ]

    monthly = pd.DataFrame(index=df.resample("MS").size().index)

    # Moyennes mensuelles
    for col in [
        "T2M",
        "T2M_MAX",
        "T2M_MIN",
        "RH2M"
    ]:
        monthly[col] = df[col].resample("MS").mean()

    # Cumuls mensuels
    for col in [
        "PRECTOTCORR",
        "ALLSKY_SFC_SW_DWN"
    ]:
        monthly[col] = df[col].resample("MS").sum(min_count=1)

    # Nombre de jours valides pour chaque variable
    for col in variables:
        monthly[f"{col}_valid_days"] = (
            df[col].resample("MS").count()
        )

    # Un mois est accepté si au moins 90 % des jours
    # attendus sont disponibles pour la variable.
    for col in variables:
        expected = df[col].resample("MS").size()
        coverage = monthly[f"{col}_valid_days"] / expected

        monthly.loc[coverage < 0.90, col] = float("nan")

    monthly.index.name = "date"

    monthly.to_csv(
        PROCESSED_DIR / f"{site_name.lower()}_monthly.csv"
    )

    print("\nDONNEES MENSUELLES GENEREES")

    return monthly


# ==========================================
# 5. EXECUTION
# ==========================================

if __name__ == "__main__":

    all_data = []

    for site_name, coordinates in SITES.items():

        daily = collect_data(site_name, coordinates)

        quality_report(daily, site_name)

        monthly = monthly_analysis(daily, site_name)

        all_data.append(daily)

    final_data = pd.concat(all_data)

    final_data.to_csv(
        PROCESSED_DIR / "niayes_daily.csv",
        encoding="utf-8"
    )

    print("\n================================")
    print("SUNU ROTATION AI")
    print("COLLECTE CLIMATIQUE TERMINEE")
    print("================================")

print(df.describe().round(2))